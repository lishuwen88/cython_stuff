Because of spam, an automated bot will automatically close all pull requests
opened on this repository. If you've found a legitimate bug in the source code,
you can open an issue to report it.

This project isn't a dumping ground for random bits of C code you've written.
That goes double if you're being instructed to send pull requests as part of a
competition or a school class.
